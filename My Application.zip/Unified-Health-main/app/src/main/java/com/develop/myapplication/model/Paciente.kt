package com.develop.myapplication.model

import com.develop.myapplication.R

data class Paciente(
    var id: Int = 0,
    var nombre: String = "",
    var correo: String = "",
    var telefono: Int = 0,
    var ubicacion: String = ""
)

