package com.develop.myapplication.model

import com.example.myapplication.model.Paciente
import com.example.eventmaster.remote.ApiService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

class PacienteRepository @Inject constructor(
    private val apiService: apiService
) {
    private val _categories = MutableSharedFlow<List<Paciente>>(replay = 1)
    val categories: SharedFlow<List<Paciente>> = _categories.asSharedFlow()

    suspend fun refreshCategories() {
        try {
            val dtoList = apiService.getCategories()
            val domainList = dtoList.map { it.toDomain() }
            _categories.emit(domainList)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun insertCategory(category: CategoryData) {
        apiService.createCategory(
            CategoryRequestDto(
                category.nombre,
                category.correo,
                category.telefono,
                category.ubicacion
            )
        )

    }

    suspend fun deleteCategory(category: Paciente) {
        try {
            apiService.deleteCategory(category.id)
            refreshCategories()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}