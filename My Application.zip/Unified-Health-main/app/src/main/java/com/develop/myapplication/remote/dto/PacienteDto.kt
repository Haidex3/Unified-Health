package com.develop.myapplication.remote.dto

data class PacienteDto(
    @SerializedName("id") val id : Int,
    @SerializedName("nombre") val nombre: String,
    @SerializedName("correo") val correo: String,
    @SerializedName("telefono") val telefono: Int,
    @SerializedName("ubicacion") val ubicacion: String

)