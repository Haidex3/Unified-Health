package com.develop.myapplication.remote.service

import com.develop.myapplication.remote.dto.PacienteDto

interface PacienteApiService {
    @get("pacientes")
    suspend fun getPacientes(): List<PacienteDto>

    @get("actividad/{id}")
    suspend fun getPacietesById(@Path("id") id : Int) : PacienteDto

    @get("pacientes")
    suspend fun createPaciente(@Body paciente: PacienteDto) : PacienteDto
}